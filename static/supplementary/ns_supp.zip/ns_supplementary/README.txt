Find here supplementary materials for Formalizing Neurath's ship: Algorithms for online causal learning

See "additional plots" for four oversized figures mentioned in the Results sections for Experiments 1 and 2.  Specifically, there is one figure detailing the types of interventions performed in the four variable problems in Experiment 1 (intervention_choices_exp1_4variable.pdf); one for interventions performed in general in Experiment 2 (intervention_choices_e2.pdf); one for types of interventions performed and the average performance of simulations on Experiment 1 (intervention_simulations_e1.pdf); and one with the same for Experiment 2 (intervention_simulations_e2.pdf).

See "demos" for demos of both Experiments 1 and 2.  These can be run in any browser by double clicking the '.html' file, provided Flash is installed and enabled.

See "data" for all the behavioral and modeling data from both experiments in the .rdata format.  This can be opened in R (https://www.r-project.org/).  Please contact neil.bramley@ucl.ac.uk for additional details about the meaning of column headings etc.

Finally, see "free response coding" for full details of how the free responses elicited in Experiment 2 were independently coded, including all the responses, the instructions given to coders and the resulting codes for both coders.